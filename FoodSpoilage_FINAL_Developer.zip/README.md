# Food Spoilage Intelligent Monitoring System — Phase 9.1

Developer-ready frozen inference package built from the supplied Phase 9.1 training artifacts.

## Frozen model
- Model: independent food-specific XGBoost classifiers
- Foods: 15
- Feature schema: 201
- Classifier target: Spoiled classes 0/1/2
- Hard-coded sensor thresholds: false
- Chronological history: supported
- Risk: probability-based
- RUL: dataset-derived estimate; not supervised time-to-failure

## Food models
Apple, Beef, Bread, Cheese, Chicken, Eggs, Fish, Milk, Mushroom, Orange,
Potato, Spinach, Strawberry, Tomato, Yogurt.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000
```

Windows activation:
```powershell
.venv\Scripts\activate
```

API:
- `GET /health`
- `GET /foods`
- `GET /history/{batch_id}`
- `DELETE /history/{batch_id}`
- `POST /predict`
- `POST /sensor`

OpenAPI docs:
`http://localhost:8000/docs`

## Architecture

Sensor hardware → CURL/HTTP JSON → API → food-specific model → exact 201-feature
schema → spoilage probabilities → risk score/reasons → estimated RUL → website.

## Compatibility

The bundled `imputer.joblib` artifacts were serialized with scikit-learn 1.6.1.
The requirements file intentionally pins scikit-learn to 1.6.1. Do not change that
version casually when deploying the frozen package.

## Important model limitation

The training dataset does not contain a true time-to-failure/RUL target. Therefore
the current RUL is a dataset-derived estimate, not a directly supervised RUL prediction.
